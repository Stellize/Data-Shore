TIDE ATLAS · TIDE TABLES 2019-2025

Seven years of hand-transcribed tide tables for the estuary and headland.
Each file covers one calendar year. Times are local; heights are metres above
chart datum. Where the harbour board and the keeper's notebook disagreed,
both figures are kept in the notes column.

These tables are a record of attention, not a navigation aid.
